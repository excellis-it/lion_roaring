@if ($mails->count() > 0)
    @foreach ($mails as $mail)
        @php
            // Prefer controller-provided user info for the thread; fall back to userMail if present
            $mailUser = $mail->ownUserMailInfo ?? ($mail->userMail ?? null);
            // Row is considered read only when the thread has no unread messages
            $isRead = (int) ($mail->unread_count ?? 0) === 0;
            $latestReply = $mail->replies->first();
            $isStar = $mailUser ? $mailUser->is_starred : 0;
        @endphp
        <div class="emailRow {{ $isRead ? '' : 'mail_read' }}">
            <div class="emailRow__options gap-2">
                <input type="checkbox" class="selectMail" id="check-box" data-id="{{ $mail->id }}" />
                {{-- <span class="material-symbols-outlined"> star_border </span> --}}
                @if ($isStar == 1)
                    <a href="javascript:void(0);" onclick="setMailStar(this, {{ $mail->id }})">
                        <span class="material-symbols-outlined"
                            style="color: orange; font-variation-settings: 'FILL' 1;">grade</span></a>
                @else
                    <a href="javascript:void(0);" onclick="setMailStar(this, {{ $mail->id }})">
                        <!-- <span class="material-symbols-outlined">grade</span> -->
                        <i class="fa-regular fa-star"></i>
                    </a>
                @endif
            </div>


            <h3 class="emailRow__title view-mail"
                data-route="{{ route('mail.view', base64_encode(!empty($mail->reply_of) ? $mail->reply_of : $mail->id)) }}">
                {{ $mail->user->full_name ?? '' }}
            </h3>

            <div class="emailRow__message view-mail"
                data-route="{{ route('mail.view', base64_encode(!empty($mail->reply_of) ? $mail->reply_of : $mail->id)) }}">
                <h4>
                    {{ !empty($mail->reply_of) ? 'RE:' : '' }} {{ $mail->subject }}
                    @if ($latestReply)
                        {{-- <span class="emailRow__description"> - {!! $latestReply->message !!} </span> --}}
                        <span class="emailRow__description"> - {!! $mail->message !!} </span>
                    @else
                        <span class="emailRow__description"> - {!! $mail->message !!} </span>
                    @endif
                </h4>
            </div>

            <div class="emailRow__unread-count">
                @if ($mail->unread_count > 0)
                    <span class="badge bg-danger">{{ $mail->unread_count }} new</span>
                @endif
            </div>

            <p class="emailRow__time view-mail"
                data-route="{{ route('mail.view', base64_encode(!empty($mail->reply_of) ? $mail->reply_of : $mail->id)) }}">
                {{ $latestReply ? $latestReply->created_at->diffForHumans() : $mail->created_at->diffForHumans() }}
            </p>
        </div>
    @endforeach
@else
    <div class="mt-3 text-center">
        <h3 class="emailRow__title">No mail found</h3>
    </div>
@endif
