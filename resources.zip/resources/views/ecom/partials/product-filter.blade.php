<div class="filter_resilt">
    <div class="row align-items-center">
        <div class="col-lg-8 col-md-8">
            <div class="filter_res_text" id="count-product">
                @include('ecom.partials.count-product', [
                    'products_count' => $products_count,
                    'category' => $category,
                    'category_name' => $category_name
                ])

            </div>
        </div>
        <div class="col-lg-4 col-md-4">
            <div class="d-flex justify-content-end">
                <div class="">
                    <select class="latest_filter" name="latest_filter" id="latest_filter">
                        <option value="Latest" selected>Latest</option>
                        <option value="A to Z">A to Z</option>
                        <option value="Z to A">Z to A</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row" id="products">
    @include('ecom.partials.product-item', ['products' => $products, 'products_count' => $products_count])
    <div id="loading" style="display: none; ">
        <div style="justify-content: center; align-items: center; display:flex">
            <img src="{{ asset('ecom_assets/images/loader.gif') }}" alt="Loading..." height="50" width="50" />
        </div>
    </div>
</div>
