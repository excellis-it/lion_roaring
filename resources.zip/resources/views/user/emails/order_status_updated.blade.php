<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Order Update</title>
    <style>
        body { font-family: Arial, sans-serif; color:#333; line-height:1.5; }
        table { border-collapse: collapse; width: 100%; margin-top: 10px; }
        th, td { border:1px solid #ccc; padding: 8px; text-align: left; }
        th { background: #f3f3f3; }
        .table-primary th, .table-primary td { background: #e0f7ff; }
    </style>
</head>
<body>
    {!! $body !!}
</body>
</html>
