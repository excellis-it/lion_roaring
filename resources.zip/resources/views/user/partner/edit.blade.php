@extends('user.layouts.master')
@section('title')
    Edit Partners - {{ env('APP_NAME') }}
@endsection
@push('styles')
    <style>
        .permissions-card {
            border: 1px solid #e0e6ed;
            border-radius: 8px;
            background: #fff;
            overflow: hidden;
        }

        .permissions-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            background: #f8fbff;
            border-bottom: 1px solid #e0e6ed;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .search-wrapper {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .search-input-group {
            position: relative;
        }

        .search-input-group input {
            padding-right: 35px;
            border-radius: 6px;
            border: 1px solid #d1d9e3;
            height: 38px;
            font-size: 14px;
            width: 250px;
        }

        .category-row {
            border-bottom: 1px solid #f0f3f7;
            transition: all 0.2s;
        }

        .category-row:last-child {
            border-bottom: none;
        }

        .category-trigger {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            cursor: pointer;
            user-select: none;
        }

        .category-trigger:hover {
            background-color: #fcfdfe;
        }

        .category-info {
            display: flex;
            align-items: center;
            flex-grow: 1;
            gap: 10px;
        }

        .category-name {
            font-weight: 600;
            color: #334155;
            font-size: 0.95rem;
        }

        .perm-count-badge {
            color: #94a3b8;
            font-size: 0.8rem;
            font-weight: 400;
        }

        .selection-count-badge {
            background: #3b82f6;
            color: white;
            border-radius: 4px;
            padding: 2px 8px;
            font-size: 0.75rem;
            font-weight: 600;
            margin-right: 15px;
            min-width: 25px;
            text-align: center;
        }

        .selection-count-badge.zero {
            background: #cbd5e1;
        }

        .arrow-icon {
            transition: transform 0.3s;
            color: #64748b;
        }

        .category-row.expanded .arrow-icon {
            transform: rotate(180deg);
        }

        .permissions-grid {
            padding: 0 20px 20px 60px;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
            display: none;
        }

        .category-row.expanded .permissions-grid {
            display: grid;
        }

        .perm-item {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .perm-label {
            font-size: 0.85rem;
            color: #475569;
            cursor: pointer;
            margin-bottom: 0;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .btn-outline-action {
            border: 1px solid #3b82f6;
            color: #3b82f6;
            background: white;
            padding: 4px 12px;
            border-radius: 4px;
            font-size: 13px;
            transition: all 0.2s;
        }

        .btn-outline-action:hover {
            background: #3b82f6;
            color: white;
        }

        .form-check-input {
            width: 1.15em;
            height: 1.15em;
            cursor: pointer;
        }
    </style>
@endpush
@section('content')
    <section id="loading">
        <div id="loading-content"></div>
    </section>
    <div class="container-fluid">
        <div class="bg_white_border">
            <div class="row">
                <div class="col-lg-12">
                    <form action="{{ route('partners.update', Crypt::encrypt($partner->id)) }}" method="POST" id="uploadForm">
                        @method('PUT')
                        @csrf
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="heading_box mb-5">
                                            <h3>Login Information</h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-2">
                                        <div class="box_label">
                                            <label>User Name *</label>
                                            <input type="text" class="form-control" name="user_name" readonly
                                                value="{{ $partner->user_name }}" placeholder="">
                                            @if ($errors->has('user_name'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('user_name') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="col-md-6 mb-2">
                                        <div class="box_label">
                                            <label>Email *</label>
                                            <input type="text" class="form-control" name="email"
                                                value="{{ old('email', $partner->email) }}" placeholder="">
                                            @if ($errors->has('email'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('email') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                    @php
                                        $existing_id = $partner->lion_roaring_id;
                                        $current_prefix = $generated_id_part;
                                        $current_suffix = '';

                                        if (strlen($existing_id) >= 14 && substr($existing_id, 0, 2) === 'LR') {
                                            $current_prefix = substr($existing_id, 0, 14);
                                            $current_suffix = substr($existing_id, 14);
                                        } else {
                                            $current_suffix = $existing_id;
                                        }
                                    @endphp
                                    <div class="col-md-6 mb-2">
                                        <div class="box_label">
                                            <label>Lion Roaring ID *</label>
                                            <div class="input-group">
                                                <span
                                                    class="input-group-text">{{ old('generated_id_part', $current_prefix) }}</span>
                                                <input type="text" class="form-control" name="lion_roaring_id_suffix"
                                                    value="{{ old('lion_roaring_id_suffix', $current_suffix) }}"
                                                    placeholder="Enter last 4 digit ID/SSN" maxlength="4">
                                            </div>
                                            @if ($errors->has('lion_roaring_id_suffix'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('lion_roaring_id_suffix') }}
                                                </div>
                                            @endif
                                            <input type="hidden" name="generated_id_part"
                                                value="{{ old('generated_id_part', $current_prefix) }}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-2">
                                        <div class="box_label">
                                            <label>Roar ID *</label>
                                            <input type="text" class="form-control" name="roar_id"
                                                value="{{ old('roar_id', $partner->roar_id) }}" placeholder="">
                                            @if ($errors->has('roar_id'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('roar_id') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                    {{-- user_type --}}
                                    <div class="col-md-6 mb-2">
                                        <div class="box_label">
                                            <label>User Type *</label>
                                            <select class="form-control" name="user_type">
                                                <option value="">Select User Type</option>
                                                @foreach ($allowedUserTypes as $type)
                                                    <option value="{{ $type }}"
                                                        {{ old('user_type', $partner->user_type) == $type ? 'selected' : '' }}>
                                                        {{ $type }}</option>
                                                @endforeach
                                            </select>
                                            @if ($errors->has('user_type'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('user_type') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                    {{-- phone --}}
                                    <div class="col-md-6 mb-2">
                                        <div class="box_label">
                                            <label>Phone*</label>
                                            <input type="tel" class="form-control" name="phone" id="mobile_code"
                                                value="{{ old('full_phone_number', $partner->phone) }}"
                                                placeholder="Enter Phone Number">
                                            @if ($errors->has('phone'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('phone') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>

                                    {{-- password --}}
                                    <div class="col-md-6 mb-2">
                                        <div class="box_label position-relative">
                                            <label>Password</label>
                                            <input type="password" class="form-control" name="password" id="password"
                                                value="{{ old('password') }}" placeholder="">
                                            <span class="eye-btn-1" id="eye-button-1">
                                                <i class="fa fa-eye-slash" aria-hidden="true" id="togglePassword"></i>
                                            </span>
                                            @if ($errors->has('password'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('password') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                    {{-- confirm_password --}}
                                    <div class="col-md-6 mb-2">
                                        <div class="box_label position-relative">
                                            <label>Confirm Password</label>
                                            <input type="password" class="form-control" name="confirm_password"
                                                id="confirm_password" value="{{ old('confirm_password') }}" placeholder="">
                                            <span class="eye-btn-1" id="eye-button-2">
                                                <i class="fa fa-eye-slash" aria-hidden="true" id="togglePassword"></i>
                                            </span>
                                            @if ($errors->has('confirm_password'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('confirm_password') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>


                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="heading_box mb-5">
                                            <h3>Personal Information</h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    {{-- user_name --}}

                                    {{-- <div class="col-md-4 mb-2">
                                        <div class="box_label">
                                            <label>Roles *</label>
                                            <select class="form-control" name="role">
                                                <option value="">Select Role</option>
                                                @foreach ($roles as $item)
                                                    <option value="{{ $item->name }}"
                                                        {{ $partner->getFirstUserRoleName() == $item->name ? 'selected' : '' }}>
                                                        {{ $item->name }}</option>
                                                @endforeach
                                            </select>
                                            @if ($errors->has('role'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('role') }}
                                                </div>
                                            @endif

                                        </div>
                                    </div> --}}
                                    {{-- ecclesia_id --}}
                                    {{-- <div class="col-md-4 mb-2">
                                        <div class="box_label">
                                            <label>Ecclesia </label>
                                            <select class="form-control" name="ecclesia_id">
                                                <option value="">Select Ecclesia</option>
                                                @foreach ($ecclessias as $item)
                                                    <option value="{{ $item->id }}"
                                                        {{ $partner->ecclesia_id == $item->id ? 'selected' : '' }}>
                                                        {{ $item->full_name ?? '' }}</option>
                                                @endforeach
                                            </select>
                                            @if ($errors->has('ecclesia_id'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('ecclesia_id') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div> --}}




                                    <div class="col-md-4 mb-2">
                                        <div class="box_label">
                                            <label>First Name *</label>
                                            <input type="text" class="form-control" name="first_name"
                                                value="{{ old('first_name', $partner->first_name) }}" placeholder="">
                                            @if ($errors->has('first_name'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('first_name') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                    {{-- middle_name --}}
                                    <div class="col-md-4 mb-2">
                                        <div class="box_label">
                                            <label>Middle Name</label>
                                            <input type="text" class="form-control" name="middle_name"
                                                value="{{ old('middle_name', $partner->middle_name) }}" placeholder="">
                                            @if ($errors->has('middle_name'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('middle_name') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                    {{-- last_name --}}
                                    <div class="col-md-4 mb-2">
                                        <div class="box_label">
                                            <label>Last Name *</label>
                                            <input type="text" class="form-control" name="last_name"
                                                value="{{ old('last_name', $partner->last_name) }}" placeholder="">
                                            @if ($errors->has('last_name'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('last_name') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>

                                    {{-- country --}}
                                    <div class="col-md-4 mb-2">
                                        <div class="box_label">
                                            <label>Country *</label>
                                            <select name="country" id="country" class="form-control">
                                                <option value="">Select Country</option>
                                                @foreach ($countries as $country)
                                                    <option value="{{ $country->id }}"
                                                        {{ old('country', $partner->country) == $country->id ? 'selected' : '' }}>
                                                        {{ $country->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @if ($errors->has('country'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('country') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                    {{-- state --}}
                                    <div class="col-md-4 mb-2">
                                        <div class="box_label">
                                            <label>State</label>
                                            <select name="state" id="state" class="form-control">
                                                <option value="">Select State</option>
                                            </select>
                                            @if ($errors->has('state'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('state') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-2" id="ecclesia_main_input">
                                        <div class="box_label">
                                            <label>Ecclesias </label>
                                            <select class="form-control" name="ecclesia_id">
                                                <option value="">Select Ecclesia</option>
                                                @foreach ($eclessias as $item)
                                                    <option value="{{ $item->id }}"
                                                        {{ old('ecclesia_id', $partner->ecclesia_id) == $item->id ? 'selected' : '' }}>
                                                        {{ $item->name . '(' . $item->countryName->name . ')' ?? '' }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @if ($errors->has('ecclesia_id'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('ecclesia_id') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>

                                    {{-- city --}}
                                    <div class="col-md-6 mb-2">
                                        <div class="box_label">
                                            <label>City</label>
                                            <input type="text" class="form-control" name="city"
                                                value="{{ old('city', $partner->city) }}" placeholder="">
                                            @if ($errors->has('city'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('city') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>

                                    {{-- zip --}}
                                    <div class="col-md-6 mb-2">
                                        <div class="box_label">
                                            <label>Zip</label>
                                            <input type="text" class="form-control" name="zip"
                                                value="{{ old('zip', $partner->zip) }}" placeholder="">
                                            @if ($errors->has('zip'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('zip') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="col-md-6 mb-2">
                                        <div class="box_label">
                                            <label>Address</label>
                                            <input type="text" class="form-control" name="address"
                                                value="{{ old('address', $partner->address) }}" placeholder="">
                                            @if ($errors->has('address'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('address') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                    {{-- address2 --}}
                                    <div class="col-md-6 mb-2">
                                        <div class="box_label">
                                            <label>Address 2</label>
                                            <input type="text" class="form-control" name="address2"
                                                value="{{ old('address2', $partner->address2) }}" placeholder="">
                                            @if ($errors->has('address2'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('address2') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>


                                </div>


                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <h5>{{ App\Helpers\Helper::getMenuName('role_permission', 'Role Permission') }}*
                                            </h5>


                                            @php
                                                $currentRoleName = old(
                                                    'role',
                                                    $partner->userRole->name ?? $partner->getFirstUserRoleName(),
                                                );
                                            @endphp
                                            @foreach ($roles as $role)
                                                <div class="form-check form-check-inline">
                                                    <input id="data-roles-{{ $role->id }}"
                                                        class="form-check-input data-roles" type="radio" name="role"
                                                        value="{{ $role->name }}"
                                                        data-permissions="{{ json_encode($role->permissions->pluck('name')) }}"
                                                        data-isecclesia="{{ $role->is_ecclesia }}"
                                                        {{ $currentRoleName == $role->name ? 'checked' : '' }}>
                                                    <label class="form-check-label"
                                                        for="data-roles-{{ $role->id }}">{{ $role->name }}
                                                        <small>{{ $role->is_ecclesia == 1 ? '(ECCLESIA)' : '' }}</small></label>
                                                </div>
                                            @endforeach
                                            @if ($errors->has('role'))
                                                <div class="error" style="color:red !important;">
                                                    {{ $errors->first('role') }}
                                                </div>
                                            @endif

                                        </div>
                                    </div>

                                </div>


                                @if ($errors->has('manage_ecclesia'))
                                    <div class="error" style="color:red !important;">
                                        * {{ $errors->first('manage_ecclesia') }}
                                    </div>
                                @endif

                                <div class="row mt-3" id="hoe_row" style="display: none">
                                    <div class="col-md-12">
                                        <div class="card border-0 shadow-sm"
                                            style="background: #fdfdfe; border-radius: 15px; border: 1px solid #e0e0e0 !important;">
                                            <div
                                                class="card-header bg-white border-bottom-0 pt-4 px-4 d-flex justify-content-between align-items-center">
                                                <div>
                                                    <h5 class="mb-0 text-success"><i class="fas fa-home me-2"></i> House
                                                        Of ECCLESIA*</h5>
                                                    <small class="text-muted">Select the houses this user can
                                                        manage</small>
                                                </div>
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" type="checkbox"
                                                        id="select-all-ecclesias"
                                                        style="cursor: pointer; width: 2.5em; height: 1.25em;">
                                                    <label class="form-check-label ms-2 fw-bold text-dark"
                                                        for="select-all-ecclesias" style="cursor: pointer;">Select
                                                        All</label>
                                                </div>
                                            </div>
                                            <div class="card-body p-4">
                                                <div class="row g-3">
                                                    @php
                                                        // Convert manage_ecclesia to an array (handle null case)
                                                        $selectedEcclesias =
                                                            isset($partner->manage_ecclesia) &&
                                                            $partner->manage_ecclesia !== null
                                                                ? explode(',', $partner->manage_ecclesia)
                                                                : [];
                                                    @endphp

                                                    @foreach ($eclessias as $eclessia)
                                                        <div class="col-xl-3 col-lg-4 col-md-6">
                                                            <div class="ecclesia-item p-2 mb-2 rounded border bg-white shadow-sm h-100 d-flex align-items-center"
                                                                style="transition: all 0.2s;">
                                                                <div class="form-check mb-0">
                                                                    <input id="data-eclessia-{{ $eclessia->id }}"
                                                                        class="form-check-input data-eclessia"
                                                                        type="checkbox" name="manage_ecclesia[]"
                                                                        value="{{ $eclessia->id }}"
                                                                        {{ old('role') || old('permissions') || old('manage_ecclesia') || old('first_name')
                                                                            ? (is_array(old('manage_ecclesia')) && in_array($eclessia->id, old('manage_ecclesia'))
                                                                                ? 'checked'
                                                                                : '')
                                                                            : (in_array($eclessia->id, $selectedEcclesias)
                                                                                ? 'checked'
                                                                                : '') }}
                                                                        style="cursor: pointer; width: 1.25em; height: 1.25em;">
                                                                    <label class="form-check-label ms-2"
                                                                        for="data-eclessia-{{ $eclessia->id }}"
                                                                        style="cursor: pointer; font-size: 0.9rem;">
                                                                        {{ $eclessia->name }} <br>
                                                                        <small
                                                                            class="text-muted">{{ $eclessia->countryName->name }}</small>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @endforeach
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Membership Tier Selection (Only for MEMBER_NON_SOVEREIGN) -->
                                <div class="row mt-4 d-none" id="membership-tier-section">
                                    <div class="col-md-12">
                                        <div class="card border-0 shadow-sm"
                                            style="background: #f8f9fa; border-radius: 15px;">
                                            <div class="card-header bg-white border-bottom-0 pt-4 px-4">
                                                <h5 class="mb-0 text-primary"><i class="fas fa-crown me-2"></i> Membership
                                                    Tier*</h5>
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <small class="text-muted">Select the membership plan for this
                                                        member</small>
                                                    @if ($partner->userLastSubscription && $partner->userLastSubscription->subscription_expire_date)
                                                        <span
                                                            class="badge bg-soft-info text-info border border-info px-3 py-2 rounded-pill">
                                                            <i class="fas fa-calendar-alt me-1"></i> Expires:
                                                            {{ \Carbon\Carbon::parse($partner->userLastSubscription->subscription_expire_date)->format('M d, Y') }}
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>
                                            <div class="card-body p-4">
                                                <div class="row g-3">
                                                    @foreach ($membershipTiers as $tier)
                                                        <div class="col-xl-4 col-md-6">
                                                            <div class="membership-item p-3 mb-2 rounded border bg-white shadow-sm h-100"
                                                                style="cursor: pointer; transition: all 0.2s;">
                                                                <div class="form-check position-relative h-100">
                                                                    <input class="form-check-input membership-radio"
                                                                        type="radio" name="membership_tier_id"
                                                                        value="{{ $tier->id }}"
                                                                        id="tier-{{ $tier->id }}"
                                                                        {{ (old('membership_tier_id') ?? $currentTierId) == $tier->id ? 'checked' : '' }}
                                                                        style="cursor: pointer;">
                                                                    <label class="form-check-label ms-2 d-block"
                                                                        for="tier-{{ $tier->id }}"
                                                                        style="cursor: pointer;">
                                                                        <div class="fw-bold text-dark">{{ $tier->name }}
                                                                        </div>
                                                                        <div class="small text-muted">
                                                                            {{ $tier->pricing_type == 'token' ? $tier->life_force_energy_tokens . ' Tokens' : '$' . $tier->cost }}
                                                                        </div>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @endforeach
                                                </div>
                                                @if ($errors->has('membership_tier_id'))
                                                    <div class="error mt-3"
                                                        style="color:red !important; font-weight: bold;">
                                                        <i class="fas fa-exclamation-circle me-1"></i>
                                                        {{ $errors->first('membership_tier_id') }}
                                                    </div>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>



                                <div class="row mt-4" id="permissions-section">
                                    <div class="col-md-12">
                                        <div class="permissions-card">
                                            <div class="permissions-header">
                                                <div class="form-check d-flex align-items-center mb-0">
                                                    <input class="form-check-input" type="checkbox"
                                                        id="select-all-permissions">
                                                    <label class="form-check-label ms-2 fw-medium text-muted"
                                                        for="select-all-permissions" style="font-size: 14px;">
                                                        Select All Permissions
                                                    </label>
                                                </div>

                                                <div class="search-wrapper">
                                                    <div class="search-input-group">
                                                        <input type="text" id="permission-search" autocomplete="off"
                                                            placeholder="Search modules or permissions">
                                                        <i class="fas fa-search position-absolute"
                                                            style="right: 12px; top: 12px; color: #cbd5e1;"></i>
                                                    </div>
                                                    <button type="button" class="btn-outline-action"
                                                        id="collapse-all">Collapse All</button>
                                                    <button type="button" class="btn-outline-action"
                                                        id="expand-all">Expand All</button>
                                                </div>
                                            </div>

                                            <div class="permissions-body p-4">
                                                @foreach ($categorizedPermissions as $mainCategory => $subCategories)
                                                    @php
                                                        $mainCategoryPermCount = 0;
                                                        foreach ($subCategories as $subPerms) {
                                                            $mainCategoryPermCount += count(
                                                                array_intersect($subPerms, $allPermsArray),
                                                            );
                                                        }
                                                    @endphp

                                                    @if ($mainCategoryPermCount > 0)
                                                        <div class="main-category-block mb-4 shadow-sm"
                                                            style="border: 1px solid #e2e8f0; border-radius: 10px; overflow: hidden;">
                                                            <div class="main-category-header p-3 d-flex justify-content-between align-items-center"
                                                                style="background: #f8fafc; border-bottom: 1px solid #e2e8f0;">
                                                                <h5 class="mb-0"
                                                                    style="color: #1e293b; font-size: 1.1rem; font-weight: 700;">
                                                                    <i class="fas fa-layer-group me-2"
                                                                        style="color: #64748b;"></i>
                                                                    {{ $mainCategory }}
                                                                </h5>
                                                                <div class="d-flex align-items-center gap-3">
                                                                    <span class="badge bg-soft-info text-info px-3 py-2"
                                                                        style="background-color: #e0f2fe; color: #0369a1; border-radius: 6px; font-size: 0.85rem;">
                                                                        {{ $mainCategoryPermCount }} total permissions
                                                                    </span>
                                                                    <button type="button"
                                                                        class="btn btn-sm btn-outline-secondary toggle-main-category"
                                                                        style="padding: 2px 8px;">
                                                                        <i class="fas fa-chevron-up"></i>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                            <div class="main-category-content">
                                                                @foreach ($subCategories as $subCategory => $permissions)
                                                                    @php
                                                                        $availablePermissions = array_intersect(
                                                                            $permissions,
                                                                            $allPermsArray,
                                                                        );
                                                                    @endphp
                                                                    @if (count($availablePermissions) > 0)
                                                                        <div class="category-row border-bottom"
                                                                            data-category="{{ strtolower($subCategory) }}">
                                                                            <div class="category-trigger py-3 px-4">
                                                                                <div class="form-check mb-0 me-3">
                                                                                    <input
                                                                                        class="form-check-input select-category-permissions"
                                                                                        type="checkbox"
                                                                                        id="cat-check-{{ Str::slug($mainCategory . '-' . $subCategory) }}">
                                                                                </div>
                                                                                <div class="category-info">
                                                                                    <span class="category-name"
                                                                                        style="color: #334155; font-weight: 600;">{{ $subCategory }}</span>
                                                                                    <span class="perm-count-badge ms-2"
                                                                                        style="color: #64748b; font-size: 0.8rem;">({{ count($availablePermissions) }}
                                                                                        perms)</span>
                                                                                </div>
                                                                                <div class="d-flex align-items-center">
                                                                                    <span
                                                                                        class="selection-count-badge zero me-3">0</span>
                                                                                    <i class="fas fa-chevron-down arrow-icon"
                                                                                        style="color: #94a3b8;"></i>
                                                                                </div>
                                                                            </div>
                                                                            <div class="permissions-grid px-5 pb-4">
                                                                                @foreach ($availablePermissions as $permName)
                                                                                    @php
                                                                                        $perm = $allPermissions
                                                                                            ->where('name', $permName)
                                                                                            ->first();
                                                                                        $permId = $perm ? $perm->id : 0;
                                                                                    @endphp
                                                                                    <div class="perm-item"
                                                                                        data-name="{{ strtolower($permName) }}">
                                                                                        <div class="form-check mb-0">
                                                                                            <input
                                                                                                class="form-check-input permission-checkbox"
                                                                                                type="checkbox"
                                                                                                name="permissions[]"
                                                                                                value="{{ $permName }}"
                                                                                                id="perm-{{ $permId }}"
                                                                                                {{ old('role') || old('permissions') || old('manage_ecclesia') || old('first_name')
                                                                                                    ? (is_array(old('permissions')) && in_array($permName, old('permissions'))
                                                                                                        ? 'checked'
                                                                                                        : '')
                                                                                                    : ($currentPermissions->contains($permName)
                                                                                                        ? 'checked'
                                                                                                        : '') }}>
                                                                                            <label class="perm-label ms-2"
                                                                                                for="perm-{{ $permId }}"
                                                                                                title="{{ $permName }}"
                                                                                                style="font-size: 0.9rem; color: #475569;">
                                                                                                {{ $permName }}
                                                                                            </label>
                                                                                        </div>
                                                                                    </div>
                                                                                @endforeach
                                                                            </div>
                                                                        </div>
                                                                    @endif
                                                                @endforeach
                                                            </div>
                                                        </div>
                                                    @endif
                                                @endforeach
                                            </div>
                                        </div>

                                        @if ($errors->has('permissions'))
                                            <div class="error mt-3" style="color:red !important; font-weight: bold;">
                                                <i class="fas fa-exclamation-circle me-1"></i>
                                                {{ $errors->first('permissions') }}
                                            </div>
                                        @endif
                                    </div>
                                </div>

                                <div class="w-100 text-end d-flex align-items-center justify-content-end mt-4">
                                    <button type="submit" class="print_btn me-2">Update</button>
                                    <a class="print_btn print_btn_vv" href="{{ route('partners.index') }}">Cancel</a>
                                </div>

                            </div>
                        </div>
                    </form>


                    {{-- <div class="card card-body shadow-lg mt-2">
                        <h5 class="mt-0" id="Role_Name"></h5>
                        <div class="row container mt-1" id="permissions-container">
                        </div>
                    </div> --}}

                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script>
        $(document).ready(function() {
            $("#uploadForm").on("submit", function(e) {
                // e.preventDefault();
                $('#loading').addClass('loading');
                $('#loading-content').addClass('loading-content');
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            $('#eye-button-1').click(function() {
                $('#password').attr('type', $('#password').is(':password') ? 'text' : 'password');
                $(this).find('i').toggleClass('fa-eye-slash fa-eye');
            });
            $('#eye-button-2').click(function() {
                $('#confirm_password').attr('type', $('#confirm_password').is(':password') ? 'text' :
                    'password');
                $(this).find('i').toggleClass('fa-eye-slash fa-eye');
            });
        });
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.12/css/intlTelInput.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.11/jquery.mask.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.12/js/intlTelInput-jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.12/js/utils.min.js"></script>

    <script>
        function initializeIntlTelInput() {
            const phoneInput = $("#mobile_code");

            phoneInput.intlTelInput({
                geoIpLookup: function(callback) {
                    $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
                        const countryCode = (resp && resp.country) ? resp.country : "US";
                        callback(countryCode);
                    });
                },
                initialCountry: "auto",
                separateDialCode: true,
            });

            const selectedCountry = phoneInput.intlTelInput('getSelectedCountryData');
            const dialCode = selectedCountry.dialCode;
            const exampleNumber = intlTelInputUtils.getExampleNumber(selectedCountry.iso2, 0, 0);

            let maskNumber = intlTelInputUtils.formatNumber(exampleNumber, selectedCountry.iso2, intlTelInputUtils
                .numberFormat.NATIONAL);
            maskNumber = maskNumber.replace('+' + dialCode + ' ', '');

            let mask;
            if (dialCode && dialCode.length > 2) {
                // Use a fixed mask pattern for countries with dial codes of length greater than 2
                mask = '999 999 999';
                maskNumber = '999 999 999';
            } else {
                // Dynamically create a mask by replacing digits with 0 for shorter dial codes
                mask = maskNumber.replace(/[0-9+]/g, '0');
            }

            // Apply the mask with the placeholder
            phoneInput.mask(mask, {
                placeholder: 'Enter Phone Number',
            });

            phoneInput.on('countrychange', function() {
                $(this).val('');
                const newSelectedCountry = $(this).intlTelInput('getSelectedCountryData');
                const newDialCode = newSelectedCountry.dialCode;
                const newExampleNumber = intlTelInputUtils.getExampleNumber(newSelectedCountry.iso2, 0, 0);

                let newMaskNumber = intlTelInputUtils.formatNumber(newExampleNumber, newSelectedCountry.iso2,
                    intlTelInputUtils.numberFormat.NATIONAL);
                newMaskNumber = newMaskNumber.replace('+' + newDialCode + ' ', '');

                let newMask;

                if (newDialCode.length > 2) {
                    // If dial code length is more than 2, use a 999 999 999 mask (or a similar format)
                    newMask = '999 999 999';
                    newMaskNumber = '999 999 999';
                } else {
                    // Otherwise, replace all digits with 0
                    newMask = newMaskNumber.replace(/[0-9+]/g, '0');
                }

                phoneInput.mask(newMask, {
                    placeholder: 'Enter Phone Number',
                });
            });
        }

        function setPhoneNumber() {
            const phoneInput = $("#mobile_code");
            const fullNumber = "{{ $partner->phone }}";

            if (fullNumber) {
                phoneInput.intlTelInput("setNumber", fullNumber);
            }
        }

        $(document).ready(function() {
            initializeIntlTelInput();
            setPhoneNumber();

            $('form').on('submit', function() {
                const phoneInput = $("#mobile_code");
                const fullNumber = phoneInput.intlTelInput('getNumber');
                const countryCode = phoneInput.intlTelInput('getSelectedCountryData').dialCode;
                const countryData = phoneInput.intlTelInput('getSelectedCountryData');
                const countryCodeName = countryData.iso2;


                $('<input>').attr({
                    type: 'hidden',
                    name: 'full_phone_number',
                    value: fullNumber
                }).appendTo('form');

                $('<input>').attr({
                    type: 'hidden',
                    name: 'country_code',
                    value: countryCode
                }).appendTo('form');

                $('<input>').attr({
                    type: 'hidden',
                    name: 'phone_country_code_name',
                    value: countryCodeName
                }).appendTo('form');
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            var country = $('#country').val();
            var state = {{ is_numeric($partner->state) && $partner->state != null ? $partner->state : 0 }};
            var currentEcclesiaId = {{ old('ecclesia_id', $partner->ecclesia_id) ?? 'null' }};
            var currentManageEcclesia = {!! json_encode(
                old('manage_ecclesia', isset($partner->manage_ecclesia) ? explode(',', $partner->manage_ecclesia) : []),
            ) !!};

            getStates(country, state);

            $('#country').change(function() {
                getEcclesias();
                var country = $(this).val();
                getStates(country);
            });

            $('select[name="user_type"]').change(function() {
                getEcclesias();
            });

            function getStates(country, state = 0) {
                // alert(country);
                $.ajax({
                    url: "{{ route('get.states') }}",
                    type: "get",
                    data: {
                        country: country
                    },
                    success: function(response) {
                        var states = response;
                        var html = '<option value="">Select State</option>';
                        states.forEach(stateObj => {
                            var selected = stateObj.id == state ? 'selected' : '';
                            html +=
                                `<option value="${stateObj.id}" ${selected}>${stateObj.name}</option>`;
                        });
                        $('#state').html(html);
                    }
                });
            }

            function getEcclesias() {
                var country = $('#country').val();
                var userType = $('select[name="user_type"]').val();
                if (!userType) {
                    $('select[name="ecclesia_id"]').html('<option value="">Select Ecclesia</option>');
                    $('#hoe_row .row.g-3').html('');
                    return;
                }

                if (userType === 'Regional' && !country) {
                    $('select[name="ecclesia_id"]').html('<option value="">Select Ecclesia</option>');
                    $('#hoe_row .row.g-3').html('');
                    return;
                }

                var filterCountry = (userType === 'Regional') ? country : '';

                $.ajax({
                    url: "{{ route('get.ecclesias') }}",
                    type: "get",
                    data: {
                        country: filterCountry
                    },
                    success: function(response) {
                        var selectHtml = '<option value="">Select Ecclesia</option>';
                        var checkboxHtml = '';

                        response.forEach(eclessia => {
                            // Dropdown
                            var selected = eclessia.id == currentEcclesiaId ? 'selected' : '';
                            selectHtml += '<option value="' + eclessia.id + '" ' + selected +
                                '>' +
                                eclessia.name + '(' + (eclessia.country_name ? eclessia
                                    .country_name.name : '') + ')' + '</option>';

                            // Checkboxes
                            var checked = currentManageEcclesia.includes(eclessia.id
                                .toString()) ? 'checked' : '';
                            checkboxHtml += '<div class="col-xl-3 col-lg-4 col-md-6">' +
                                '<div class="ecclesia-item p-2 mb-2 rounded border bg-white shadow-sm h-100 d-flex align-items-center" style="transition: all 0.2s;">' +
                                '<div class="form-check mb-0">' +
                                '<input id="data-eclessia-' + eclessia.id +
                                '" class="form-check-input data-eclessia" type="checkbox" name="manage_ecclesia[]" value="' +
                                eclessia.id + '" ' + checked +
                                ' style="cursor: pointer; width: 1.25em; height: 1.25em;">' +
                                '<label class="form-check-label ms-2" for="data-eclessia-' +
                                eclessia.id + '" style="cursor: pointer; font-size: 0.9rem;">' +
                                eclessia.name + '<br>' +
                                '<small class="text-muted">' + (eclessia.country_name ? eclessia
                                    .country_name.name : '') + '</small>' +
                                '</label>' +
                                '</div>' +
                                '</div>' +
                                '</div>';
                        });

                        $('select[name="ecclesia_id"]').html(selectHtml);
                        $('#hoe_row .row.g-3').html(checkboxHtml);

                        if (typeof updateSelectAllEcclesiasState === 'function') {
                            updateSelectAllEcclesiasState();
                        }
                    }
                });
            }

            getEcclesias();

            // Function to update "Select All" state for ecclesias
            function updateSelectAllEcclesiasState() {
                var total = $('.data-eclessia').length;
                var checked = $('.data-eclessia:checked').length;
                $('#select-all-ecclesias').prop('checked', total > 0 && total === checked);
            }

            // Function to update Selection Counts and All/Category checkbox states
            function updateSelectionStates() {
                var totalPerms = $('.permission-checkbox').length;
                var totalChecked = $('.permission-checkbox:checked').length;

                // Update Global Select All
                $('#select-all-permissions').prop('checked', totalPerms > 0 && totalPerms === totalChecked);

                // Update Category-level states
                $('.category-row').each(function() {
                    var $row = $(this);
                    var $perms = $row.find('.permission-checkbox');
                    var $catCheck = $row.find('.select-category-permissions');
                    var $countBadge = $row.find('.selection-count-badge');

                    var catTotal = $perms.length;
                    var catChecked = $perms.filter(':checked').length;

                    $catCheck.prop('checked', catTotal > 0 && catTotal === catChecked);
                    $countBadge.text(catChecked);

                    if (catChecked > 0) {
                        $countBadge.removeClass('zero');
                    } else {
                        $countBadge.addClass('zero');
                    }
                });
            }

            // Init counts
            updateSelectionStates();

            // Toggle Main Category
            $(document).on('click', '.toggle-main-category', function() {
                var $content = $(this).closest('.main-category-block').find('.main-category-content');
                var $icon = $(this).find('i');
                $content.slideToggle();
                $icon.toggleClass('fa-chevron-up fa-chevron-down');
            });

            // Toggle Accordion
            $(document).on('click', '.category-trigger', function(e) {
                if ($(e.target).closest('.form-check').length) return;
                $(this).closest('.category-row').toggleClass('expanded');
            });

            // Expand All
            $('#expand-all').click(function() {
                $('.category-row').addClass('expanded');
            });

            // Collapse All
            $('#collapse-all').click(function() {
                $('.category-row').removeClass('expanded');
            });

            // Global Select All
            $('#select-all-permissions').change(function() {
                var isChecked = $(this).prop('checked');
                $('.permission-checkbox, .select-category-permissions').prop('checked', isChecked);
                updateSelectionStates();
            });

            // Category Select All
            $(document).on('change', '.select-category-permissions', function() {
                var isChecked = $(this).prop('checked');
                $(this).closest('.category-row')
                    .find('.permission-checkbox')
                    .prop('checked', isChecked);
                updateSelectionStates();
            });

            // Individual Permission Change
            $(document).on('change', '.permission-checkbox', function() {
                updateSelectionStates();
            });

            // Search Logic
            $('#permission-search').on('keyup', function() {
                var val = $(this).val().toLowerCase();

                $('.category-row').each(function() {
                    var $row = $(this);
                    var catName = $row.data('category');
                    var hasVisiblePerm = false;

                    $row.find('.perm-item').each(function() {
                        var $item = $(this);
                        var permName = $item.data('name');

                        if (permName.includes(val) || catName.includes(val)) {
                            $item.show();
                            hasVisiblePerm = true;
                        } else {
                            $item.hide();
                        }
                    });

                    if (hasVisiblePerm) {
                        $row.show();
                        if (val.length > 0) {
                            $row.addClass('expanded');
                        }
                    } else {
                        $row.hide();
                    }
                });

                if (val.length === 0) {
                    $('.category-row').removeClass('expanded');
                }
            });


            // Select/Unselect All Toggle for Ecclesias
            $('#select-all-ecclesias').change(function() {
                $('.data-eclessia').prop('checked', $(this).prop('checked'));
            });

            // Individual Ecclesia Click
            $(document).on('change', '.data-eclessia', function() {
                updateSelectAllEcclesiasState();
            });

            // Make the entire card clickable
            $(document).on('click', '.permission-item, .ecclesia-item', function(e) {
                if (!$(e.target).is('input') && !$(e.target).is('label')) {
                    var checkbox = $(this).find('input[type="checkbox"]');
                    checkbox.prop('checked', !checkbox.prop('checked')).trigger('change');
                }
            });

            function updatePermissions(permissions, is_ecclesia) {
                if (is_ecclesia == 1) {
                    $("#hoe_row").show();
                    $("#ecclesia_main_input").hide();
                } else {
                    $("#hoe_row").hide();
                    $("#ecclesia_main_input").show();
                }

                // Uncheck all permissions first
                $('.permission-checkbox').prop('checked', false);

                // Check permissions corresponding to the selected role
                if (permissions && Array.isArray(permissions)) {
                    permissions.forEach(function(permName) {
                        $('.permission-checkbox[value="' + permName + '"]').prop('checked', true);
                    });
                }

                // Update Select All state after role change
                updateSelectionStates();
            }

            function togglePermissionsAndMembership() {
                var checkedRadio = $('input[name="role"]:checked');
                var selectedRole = checkedRadio.val();

                if (selectedRole === 'MEMBER_NON_SOVEREIGN') {
                    $('#permissions-section').addClass('d-none');
                    $('#membership-tier-section').removeClass('d-none');
                    if ($('input[name="membership_tier_id"]:checked').length === 0) {
                        $('input[name="membership_tier_id"]').first().prop('checked', true);
                    }
                } else {
                    $('#permissions-section').removeClass('d-none');
                    $('#membership-tier-section').addClass('d-none');
                }

                // Handle Ecclesia Row visibility
                var is_ecclesia = checkedRadio.data('isecclesia');
                if (is_ecclesia == 1) {
                    $("#hoe_row").show();
                    $("#ecclesia_main_input").hide();
                    // Optional: if you used another ID somewhere
                    // $('#house-of-ecclesia-section').removeClass('d-none');
                } else {
                    $("#hoe_row").hide();
                    $("#ecclesia_main_input").show();
                }
            }

            // Combined Roles Change Handler
            $(document).on('change', 'input[name="role"]', function() {
                getEcclesias(); // Trigger ecclesia fetching on role change
                var permissions = $(this).data('permissions');
                var is_ecclesia = $(this).data('isecclesia');

                // Original permission updating logic
                updatePermissions(permissions, is_ecclesia);

                // Toggle membership section
                togglePermissionsAndMembership();
            });

            $(document).on('click', '.membership-item', function(e) {
                if (!$(e.target).is('input') && !$(e.target).is('label')) {
                    $(this).find('input[type="radio"]').prop('checked', true).trigger('change');
                }
            });

            // Initial call to set state on page load
            updateSelectionStates();
            updateSelectAllEcclesiasState();
            togglePermissionsAndMembership();
        });
    </script>
    <style>
        .ecclesia-item:hover {
            border-color: #198754 !important;
            background-color: #f0fff4 !important;
            transform: translateY(-2px);
        }

        .data-eclessia:checked+.form-check-label {
            color: #198754;
            font-weight: 600;
        }
    </style>
@endpush
