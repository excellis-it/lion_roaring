@php
    use App\Helpers\Helper;
@endphp
<footer class="footer_sec">
    <div class="container">
        <div class="copyright">
            <div class="row justify-content-between">
                <div class="col-lg-5">
                    <div class="ftr_logo_sec">
                        <div class="d-flex align-items-center">
                            <div>
                                <a class="ftr_logo">
                                    @if (isset(Helper::getFooter()['footer_logo']))
                                        <img src="{{ Storage::url(Helper::getFooter()['footer_logo']) }}" alt="">
                                    @else
                                        <img src="{{ asset('frontend_assets/uploads/2024/02/Group-2029.png') }}"
                                            alt="">
                                    @endif
                                </a>
                            </div>
                            <div>
                                <a class="ftr_logo_right">
                                    @if (isset(Helper::getFooter()['footer_flag']))
                                        <img src="{{ Storage::url(Helper::getFooter()['footer_flag']) }}"
                                            alt="">
                                    @else
                                        <img src="{{ asset('frontend_assets/uploads/2024/02/Group-2029.png') }}"
                                            alt="">
                                    @endif
                                </a>
                            </div>
                        </div>

                        <p>
                            {!! Helper::getFooter()['footer_title'] ??
                                'Our main focus is to restore our various communities, villages, cities, states,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    and
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    our nation by restoring the condition of a person in both the spiritual and the
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    physical.' !!}
                        </p>
                        <div class="col-lg-12">
                            <div class="d-flex align-items-center">
                                <a href="{{ Helper::getFooter()['footer_playstore_link'] ?? 'javascript:void(0);' }}"
                                    class="me-2">
                                    @if (isset(Helper::getFooter()['footer_playstore_link']))
                                        <img src="{{ Storage::url(Helper::getFooter()['footer_playstore_image']) }}"
                                            alt="">
                                    @else
                                        <img src="{{ asset('frontend_assets/uploads/2024/01/playstore.png') }}"
                                            alt="">
                                    @endif
                                </a>
                                <a href="{{ Helper::getFooter()['footer_appstore_link'] ?? 'javascript:void(0);' }}">
                                    @if (isset(Helper::getFooter()['footer_appstore_link']))
                                        <img src="{{ Storage::url(Helper::getFooter()['footer_appstore_image']) }}"
                                            alt="">
                                    @else
                                        <img src="{{ asset('frontend_assets/uploads/2024/01/appstore.png') }}"
                                            alt="">
                                    @endif
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="find-us">
                        <h4>{!! Helper::getFooter()['footer_newsletter_title'] ?? 'Don’t miss our newsletter! Get in touch today!' !!}</h4>
                        <div class="ftr-frm">
                            <div class="wpcf7 js" id="wpcf7-f52-o1" lang="en-US" dir="ltr">
                                <div class="screen-reader-response">
                                    <p role="status" aria-live="polite" aria-atomic="true"></p>
                                    <ul></ul>
                                </div>
                                <form action="{{ route('newsletter') }}" method="post" id="submit-newsletter">
                                    @csrf
                                    <div class="row">
                                        <div class="form-group col-lg-6 col-md-12">
                                            <input size="40" class="form-control" id="newsletter_name"
                                                placeholder="Full Name" value="" type="text"
                                                name="newsletter_name">
                                            <span class="text-danger" id="newsletter_name_error"></span>
                                        </div>
                                        <div class="form-group col-lg-6 col-md-12">
                                            <input class="form-control" placeholder="Email ADDRESS"
                                                id="newsletter_email" value="" type="email"
                                                name="newsletter_email">
                                            <span class="text-danger" id="newsletter_email_error"></span>
                                        </div>
                                        <div class="form-group col-12">
                                            <textarea cols="40" rows="10" class="form-control" id="newsletter_message" placeholder="Message"
                                                name="newsletter_message"></textarea>
                                            <span class="text-danger" id="newsletter_message_error"></span>
                                        </div>
                                    </div>
                                    <div class="main-btn">
                                        <input class="red_btn" type="submit" value="Submit">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>
    <div class="copy_1">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-12 col-lg-9">
                    <div class="quick_links_ul">
                        <ul class="menu" style="white-space: nowrap">
                            <li class="active">
                                <a href="{{ route('home') }}" aria-current="page">Home</a>
                            </li>
                            <li>
                                <a href="{{ Helper::getPDFAttribute() ?? 'javascript:void(0);' }}"
                                    target="_blank">Article of
                                    Agreement</a>
                            </li>
                            <li class="active">
                                <a href="{{ route('privacy-policy') }}" aria-current="page">Privacy Policy</a>
                            </li>
                            <li class="active">
                                <a href="{{ route('terms-and-conditions') }}" aria-current="page">Terms and
                                    Conditions</a>
                            </li>
                            {{-- <li>
                                <a href="{{route('contact-us')}}">Contact Us</a>
                            </li> --}}
                        </ul>
                    </div>
                </div>

                <div class="col-md-12 col-lg-3">
                    {{-- <span class="badge bg-dark"> <i class="fa fa-globe"></i>
                        {{ Helper::getVisitorCountryName() }}</span> --}}

                    @php
                        $currentCode = strtoupper(\App\Helpers\Helper::getVisitorCountryCode());
                        $countries = \App\Helpers\Helper::getCountries();
                    @endphp

                    {{-- {{ collect($countries ?? [])->map(fn($c) => strtoupper($c->code ?? ($c['code'] ?? '')))->filter()->map(fn($code) => '"' . $code . '"')->implode(',') . ',' }} --}}

                    <div class="input-group input-group-sm">
                        {{-- <span class="input-group-text bg-dark text-white">
                            <img style="height: 20px;"
                                src="{{ asset('frontend_assets/images/flags/' . strtolower($currentCode) . '.png') }}"
                                alt="">
                        </span> --}}
                        <select class="countrySwitcher form-select form-select-sm cst-select cst-select-top">
                            @foreach ($countries as $c)
                                <option value="{{ strtolower($c->code) }}"
                                    {{ strtoupper($c->code) === $currentCode ? 'selected' : '' }}
                                    data-image="{{ asset('frontend_assets/images/flags/' . strtolower($c->code) . '.png') }}">
                                    {{ $c->name }} ({{ strtoupper($c->code) }})
                                </option>
                            @endforeach
                        </select>
                    </div>

                </div>
            </div>
        </div>
    </div>
</footer>
<section class="copy_text-bottom">
    <div class="container">
            <div class="row">
                <div class="col-md-12 col-xxl-12">
                    <p>{!! Helper::getFooter()['footer_copywrite_text'] ??
                        'Copyright © ' . date('Y') . ' Daud Santosa. All Rights Reserved' !!}</p>
                </div>
            </div>
        </div>
</section>

<script>
    const popup = document.getElementById("popupOverlay");

    // Show popup short time after load if present and not explicitly hidden
    // window.addEventListener('load', function() {
    //     if (!popup) return;
    //     if (popup.style.display && popup.style.display === 'none') return;
    //     setTimeout(() => {
    //         popup.style.display = "flex";
    //     }, 1000);
    // });

    // Close popup
    function closePopup() {
        if (!popup) return;
        popup.style.display = "none";
    }

    // When a flag is clicked - send to server to store in session, then close/refresh
    function selectFlag(country) {
        if (!country) return;
        fetch("{{ route('set-visitor-country') }}", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                country: country
            })
        }).then(function(response) {
            if (response.ok) {
                // optionally update any UI elements (update all countrySwitchers)
                var sels = document.querySelectorAll('.countrySwitcher');
                var switchTo = '{{ route('home') }}/';
                if (sels && sels.length > 0) {
                    sels.forEach(function(s) {
                        if (s.value !== country) {
                            s.value = country;
                            // trigger change for any JS wrappers (e.g., select2) so they pick up the new value
                            try {
                                s.dispatchEvent(new Event('change', {
                                    bubbles: true
                                }));
                            } catch (e) {}
                        }
                    });
                }
                closePopup();
                // reload so server-side session check will prevent popup next time
                //  window.location.reload();
                if (country) window.location.href = switchTo + encodeURIComponent(
                    country); // goes to masked home which sets session + content
            } else {
                // still close popup on failure to avoid blocking UX
                closePopup();
            }
        }).catch(function() {
            closePopup();
        });
    }

    // Handle country selection button click
    function handleCountrySelection() {
        var selectElement = document.getElementById('popupCountrySelect');
        if (selectElement) {
            var selectedCountry = selectElement.value;
            if (selectedCountry) {
                selectFlag(selectedCountry);
            }
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        var sels = document.querySelectorAll('.countrySwitcher');
        if (sels && sels.length > 0) {
            sels.forEach(function(sel) {
                sel.addEventListener('change', function() {
                    var cc = this.value;
                    if (cc) {
                        // store session then reload via selectFlag
                        selectFlag(cc);
                    }
                });
            });
        }

        // Delegate change events for dynamically-enhanced select elements (e.g., plugins)
        document.addEventListener('change', function(e) {
            var target = e.target || e.srcElement;
            if (target && target.classList && target.classList.contains('countrySwitcher')) {
                var cc = target.value;
                if (cc) selectFlag(cc);
            }
        }, false);

        // Close popup overlay helper if present
        window.closePopup = function() {
            var overlay = document.getElementById('popupOverlay');
            if (overlay) {
                overlay.style.display = 'none';
            }
        };
    });




    //    document.addEventListener('DOMContentLoaded', function() {
    //     var sel = document.getElementById('countrySwitcher');
    //     var switchTo = '{{ route('home') }}/'; // base home URL; append country code
    //     if (sel) {
    //         sel.addEventListener('change', function() {
    //             var cc = this.value;
    //             if (cc) window.location.href = switchTo + encodeURIComponent(
    //                 cc); // goes to masked home which sets session + content
    //         });
    //     }
    // });
</script>
