{{-- {{ dd(session()->all()) }} --}}
@extends('frontend.layouts.master')
@section('meta_title')
    <meta name="description" content="{{ $home['meta_description'] ?? '' }}">
    <meta name="keywords" content="{{ $home['meta_keywords'] ?? '' }}">
    <meta name="title" content="{{ $home['meta_title'] ?? '' }}">
@endsection
@section('title')
    {{ env('APP_NAME') }} - {{ $home['meta_title'] ?? 'Home' }}
@endsection
@push('styles')
@endpush

@section('content')

    @php
        use App\Helpers\Helper;
        $currentCode = strtoupper(Helper::getVisitorCountryCode());
        $countries = Helper::getCountries();
        // show popup only if session key not set for this IP
        $ip = request()->ip();
        $sessionKey = 'visitor_country_flag_code_' . $ip;
        // New visitor flow:
        // 1) If user hasn't selected a country yet -> show country popup first
// 2) After selecting a country and reload -> show agreement modal (handled in master)
$showPopup = !session()->has($sessionKey) && !Session::has('agree');
    @endphp

    <!--Flag Popup -->
    <div class="popup-overlay" id="popupOverlay" style="{{ $showPopup ? '' : 'display:none;' }}">
        <div class="popup-box flag-popup-box">
            {{-- <button onclick="closePopup()" class="xmark_btn"><i class="fa-solid fa-xmark"></i></button> --}}
            <div class="top-box">
                <div class="popup-logo">
                    @if (isset(Helper::getFooter()['footer_logo']))
                        <img src="{{ Storage::url(Helper::getFooter()['footer_logo']) }}" alt="">
                    @else
                        <img src="{{ asset('frontend_assets/uploads/2024/02/Group-2029.png') }}" alt="">
                    @endif
                </div>
                <!--<div class="popup-text-box">-->
                <!--    <h2>Lion Roaring</h2>-->
                <!--    <p>A habitation where supernatural and solution intersects</p>-->
                <!--</div>-->

                <!--<div class="form-box">-->
                <!--    <form>-->
                <!--        <div class="wrap">-->
                <!--            <h4>Select Your Country</h4>-->
                <!--            <div class="search">-->
                <!--                <input type="text" class="searchTerm searchCountryNameInput"-->
                <!--                    placeholder="What are you looking for?">-->
                <!--                <button type="button" class="searchButton">-->
                <!--                    <i class="fa fa-search"></i>-->
                <!--                </button>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--    </form>-->
                <!--</div>-->

            </div>

            @php
                $currentCode = strtoupper(Helper::getVisitorCountryCode());
                $countries = Helper::getCountries();
            @endphp

            <div class="popup_countrySwitcher">
                <select class="form-select form-select-sm cst-select cst-select-bottom" id="popupCountrySelect">
                    @foreach ($countries as $c)
                        <option value="{{ strtolower($c->code) }}"
                            {{ strtoupper($c->code) === $currentCode ? 'selected' : '' }}
                            data-image="{{ asset('frontend_assets/images/flags/' . strtolower($c->code) . '.png') }}">
                            {{ $c->name }} ({{ strtoupper($c->code) }})
                        </option>
                    @endforeach
                </select>
                <div class="text-center">
                    <button type="button" class="red_btn flag-btn mt-3 w-50" id="selectCountryBtn"
                        onclick="handleCountrySelection()">
                        <span>Select Country</span>
                    </button>
                </div>
            </div>
        </div>
    </div>



    <section class="banner__slider banner_sec">
        <div class="slider">
            <div class="slide">
                <a href="{{ route('details') }}" tabindex="0">
                    <div class="slide__img">
                        <video autoplay="" muted="" loop="" class="video_part" playsInline>
                            <source
                                src="{{ isset($home['banner_video']) ? Storage::url($home['banner_video']) : 'https://via.placeholder.com/150' }}"
                                type="video/mp4">
                            Your browser does not support the video tag.
                        </video>
                        <!-- <img src="" alt="" class="full-image d-block d-md-none" /> -->
                        <img src="{{ isset($home['banner_image']) ? Storage::url($home['banner_image']) : 'https://via.placeholder.com/150' }}"
                            class="full-image overlay-image">

                        {{-- <img src="{{ asset('frontend_assets/images/banner_img.png') }}" class="full-image overlay-image"> --}}
                    </div>
                </a>
                <div class="slide__content slide__content__left">
                    <div class="slide__content--headings text-left">
                        <h1 class="title">{{ $home['banner_title'] ?? 'title' }}</h1>
                        <!-- <p class="top-title"></p> -->
                        <!--<a class="red_btn slidebottomleft" ><span>get started</span></a>-->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="about_sec">
        <div class="container">
            <div class="row align-items-center justify-content-center">
                <div class="col-xxl-5 col-lg-6 mb-4" data-aos="fade-up" data-aos-duration="1000">
                    <div class="four_image">
                        <div class="row align-items-center justify-content-center">
                            @foreach ($details as $key => $chunk)
                                <div class="{{ $key % 2 == 0 ? 'col-xl-5 col-lg-6 col-md-6 col-sm-6 col-6 mb-4 top-imgs' : 'col-xl-5 col-lg-6 col-md-6 col-sm-6 col-6 mb-4 bottom-img mt-5' }} " data-aos="fade-right"
                                    data-aos-duration="{{ $key % 2 == 0 ? '800' : '1600' }}">
                                    @foreach ($chunk as $detail)
                                       <a href="{{ route('details') }}" tabindex="0">
                                        <img src="{{ Storage::url($detail->image) }}"
                                            class=" {{ $key % 2 == 0 ? 'about_four_ii mb-3' : 'about_four_ii mb-3' }}">
                                       </a>
                                    @endforeach
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
                <div class="col-xxl-5 col-lg-6" data-aos="fade-up" data-aos-duration="1000">
                    <div class="about_text heading_hp">
                        <h6>{{ $home['section_1_title'] ?? 'title' }}</h6>
                        <h2 class="text-start"> {{ $home['section_1_sub_title'] ?? 'title' }}</h2>
                        <p style="font-weight: 400;">
                            <strong>{!! $home['section_1_description'] ?? 'description' !!}</strong>
                        </p>
                    </div>
                    <a class="red_btn" data-animation-in="fadeInUp" href="{{ route('about-us') }}"><span>read
                            more</span></a>
                </div>
            </div>
        </div>
    </section>





    <section class="after_about after_about_hm display-desktop">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-xl-12">
                    <div class="book">
                        <div class="left-book-sec">
                            <div class="left-sec-img">
                                @if (isset(Helper::getFooter()['footer_logo']))
                                    <img src="{{ Storage::url(Helper::getFooter()['footer_logo']) }}" alt=""
                                        class="full-image overlay-image">
                                @else
                                    <img src="{{ asset('frontend_assets/uploads/2024/02/Group-2029.png') }}"
                                        class="full-image overlay-image" alt="">
                                @endif
                            </div>
                        </div>
                        <div id="pages" class="pages">
                            <div class="page first_page text-center">
                                <img src="{{ asset('frontend_assets/images/banner_img.png') }}" alt=""
                                    class="page_logo">
                                <div class="about_text heading_hp">
                                    <h2>{{ $home['section_3_title'] ?? 'title' }}</h2>
                                    <p> {!! $home['section_3_description'] ?? 'descripiton' !!} </p>
                                </div>
                                <div class="design_page"></div>
                            </div>
                            @if (count($our_governances) > 0)
                                @foreach ($our_governances as $key => $our_governance)
                                    <div class="page">
                                        <img src="{{ isset($our_governance->image) ? Storage::url($our_governance->image) : 'https://via.placeholder.com/150' }}"
                                            alt="">
                                        <h4 class="flex-fixed">{{ $our_governance->name }}</h4>
                                        @php
                                            $description = $our_governance->description ?? 'description';
                                            $firstPart = Str::limit(strip_tags($description), 1200, '');
                                            $restPart = Str::after($description, $firstPart);
                                        @endphp
                                        <p>{!! $firstPart ?? '' !!}</p>
                                        <div class="design_page"></div>
                                    </div>
                                    <div class="page">
                                        <p>{!! $restPart ?? '' !!}</p>
                                        <div class="design_page_right"></div>
                                    </div>
                                @endforeach
                            @endif
                            <div class="page"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
















    <section class="after_about_for_mobile common-padd">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="about_text heading_hp text-center">
                        <h2 class="text-center"> {{ $home['section_3_title'] ?? 'title' }}</h2>
                        <p style="font-weight: 400;">
                            <strong>{!! $home['section_3_description'] ?? 'descripiton' !!}</strong>
                        </p>
                    </div>
                </div>
            </div>


            <div class="reviews_slider">
                @if (count($our_governances) > 0)
                    @foreach ($our_governances as $key => $our_governance)
                        <div>
                            <div class="book-text-mobile-slider">
                                <div class="img-box">
                                    <img src="{{ isset($our_governance->image) ? Storage::url($our_governance->image) : 'https://via.placeholder.com/150' }}"
                                        alt="" class="user-img">
                                </div>
                                <div class="client-reviews">
                                    @php
                                        $description = $our_governance->description ?? 'description';
                                    @endphp
                                    <h3>{{ $our_governance->name ?? '' }} </h3>
                                    <p>{!! $description !!}</p>
                                </div>
                            </div>
                        </div>
                    @endforeach
                @endif

            </div>
        </div>
    </section>



    <div class="promo-box-container">
        <p class="title">
            <a href="{{ $home['section_6_button_link'] ?? '#' }}" target="_blank" rel="noopener">
                {{ $home['section_6_title'] ?? 'Want to create an impact?' }}
                <span class="lighter">{{ $home['section_6_subtitle'] ?? 'Gift/Seed to help us grow!!!' }}</span>
            </a>
        </p>
        <p>
            <a href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#exampleModal1" class="cta-button red_btn">
                <span>{{ $home['section_6_button_text'] ?? 'Gift/Seed' }}</span>
            </a>
        </p>
        <div class="right-triangle"> </div>
    </div>

    @if (count($our_organizations) > 0)
        <section class="real_solution_sec">
            <div class="container">
                <div class="row align-items-center justify-content-center mb-5">
                    <div class="col-lg-12">
                        <div class="about_text heading_hp text-center">
                            <h6></h6>
                            <h2>{{ $home['section_4_title'] ?? 'title' }}</h2>

                            <h4> {!! $home['section_4_description'] ?? 'description' !!}</h4>
                        </div>
                    </div>
                </div>
                <div class="">
                    @foreach ($our_organizations as $our_organization)
                        <div class="article card-4 mb-5">
                            <div class="card-body">
                                <div class="card-corner">
                                    <a href="{{ route('our-organization', $our_organization->slug) }}" class="arrow-box">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                            viewBox="0 0 24 24" fill="none">
                                            <path d="M13.75 6.75L19.25 12L13.75 17.25" stroke="#0E0E0F" stroke-width="1.5"
                                                stroke-linecap="round" stroke-linejoin="round"></path>
                                            <path d="M19 12H4.75" stroke="#0E0E0F" stroke-width="1.5"
                                                stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </a>
                                    <div class="curve-one"></div>
                                    <div class="curve-two"></div>
                                </div>
                                <div class="row align-items-center">
                                    <div class="col-lg-7">
                                        <div class="position-relative card-img hover-effect-1"
                                            style="position: relative; overflow: hidden; border-radius: 16px; cursor: pointer;">
                                            <div class="card-img-top">
                                                <a href="{{ route('service', $our_organization->slug) }}">
                                                    <img src="{{ Storage::url($our_organization->image) }}"
                                                        alt="">
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-5 card-text-box">

                                        <h4>
                                            <a
                                                href="{{ route('service', $our_organization->slug) }}">{{ $our_organization->name }}</a>
                                        </h4>
                                        <p class="word-litmit card-text" style="font-weight: 400;">
                                            {!! $our_organization->description !!}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </section>
    @endif

    @if (count($testimonials) > 0)
        <section class="testimonial_sec">
            <div class="tp-testimonial-area tp-testimonial-bg position-relative">
                <div class="tp-testimonial-global">
                    <img alt="" class="global-img" style="color:transparent"
                        src="{{ asset('frontend_assets/images/global.png') }}">
                </div>
            </div>


            <div class="container">
                <div class="row align-items-center justify-content-center mb-5 mx-0">
                    <div class="col-lg-6 px-0">
                        <div class="about_text heading_hp text-center text_white position-relative">
                            <h6></h6>
                            <h2>{{ $home['section_5_title'] ?? 'title' }}</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="testimonial_slider">
                @foreach ($testimonials as $key => $item)
                    <div class="client">
                        <div class="testimonial_box testimonial_box_{{ (($loop->iteration - 1) % 4) + 1 }}">
                            <div class="d-flex">
                                <div class="client_img">
                                    <img src="{{ Storage::url($item->image) }}" alt="">
                                </div>
                                <h2>{{ $item->name ?? 'N/A' }}<span>{{ $item->address ?? 'N/A' }}</span></h2>
                            </div>
                            <div class="client-text">
                                <div class="srlt" id="">
                                    <p>{!! $item->description !!}</p>
                                </div>
                            </div>
                        </div>
                    </div>

                @endforeach
            </div>

        </section>
    @endif

    <!-- @if (count($galleries) > 0)
    <section class="gallery_sec margin_27">
                                                                            <div class="gallery_slider">
                                                                                @foreach ($galleries as $galary)
    <div class="gallery_box" style="width: 100%; display: inline-block;">
                                                                                        <img src="{{ Storage::url($galary->image) }}" alt="">
                                                                                    </div>
    @endforeach
                                                                            </div>
                                                                        </section>
    @endif -->
@endsection

@push('scripts')
    <script>
        (function($) {
            $(document).ready(function() {

                // Prevent the search form from submitting / reloading the page
                $('.form-box').on('submit', 'form', function(e) {
                    e.preventDefault();
                });

                // Filter country tiles based on input
                var $input = $('.searchCountryNameInput');
                var $countries = $('.countryModalList');

                $input.on('input', function() {
                    var q = $.trim($(this).val()).toLowerCase();

                    if (q === '') {
                        // show all when empty
                        $countries.show();
                        return;
                    }

                    $countries.each(function() {
                        var $el = $(this);
                        // check data attributes and visible name text
                        var name = ($el.data('country-name') || $el.find('.country-name')
                            .text() || '').toString().toLowerCase();
                        var code = ($el.data('country-code') || '').toString().toLowerCase();

                        if (name.indexOf(q) !== -1 || code.indexOf(q) !== -1) {
                            $el.show();
                        } else {
                            $el.hide();
                        }
                    });
                });

                // optional: allow search button to trigger filter (in case user clicks it)
                $('.searchButton').on('click', function(e) {
                    e.preventDefault();
                    $input.trigger('input');
                });
            });
        })(jQuery);
    </script>
@endpush
