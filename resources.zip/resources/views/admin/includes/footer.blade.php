<footer class="main-footer">
    <div class="footer-left">
        Copyright © {{date('Y')}}
        <div class="bullet"></div>
        <a target="_blank" ></a>
    </div>
    <div class="footer-right"></div>
</footer>
